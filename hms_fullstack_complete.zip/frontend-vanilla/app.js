const API = "http://localhost:8080/api";

// UI helpers
const content = document.getElementById('content');
const pageTitle = document.getElementById('page-title');
const refreshBtn = document.getElementById('refreshBtn');
const navLinks = document.querySelectorAll('.sidebar nav a');

navLinks.forEach(a=>a.addEventListener('click', e=>{
  e.preventDefault();
  navLinks.forEach(x=>x.classList.remove('active'));
  a.classList.add('active');
  const tab = a.dataset.tab;
  loadTab(tab);
}));

refreshBtn.addEventListener('click', ()=> loadTab(document.querySelector('.sidebar nav a.active').dataset.tab));

async function loadCounts(){
  const [patients, doctors, appointments] = await Promise.all([fetch(API+'/patients').then(r=>r.json()), fetch(API+'/doctors').then(r=>r.json()), fetch(API+'/appointments').then(r=>r.json())]);
  document.getElementById('totalPatients').innerText = patients.length;
  document.getElementById('totalDoctors').innerText = doctors.length;
  document.getElementById('totalAppointments').innerText = appointments.length;
}

function loadTab(tab){
  pageTitle.innerText = tab.charAt(0).toUpperCase() + tab.slice(1);
  if(tab==='dashboard') {
    content.innerHTML = document.querySelector('.card.stats').outerHTML;
    loadCounts();
  } else if(tab==='patients') loadPatientsUI();
  else if(tab==='doctors') loadDoctorsUI();
  else if(tab==='appointments') loadAppointmentsUI();
}

async function loadPatientsUI(){
  const tpl = document.getElementById('patients-template').content.cloneNode(true);
  content.innerHTML=''; content.appendChild(tpl);
  const body = document.getElementById('patientsBody');
  const form = document.getElementById('patientForm');
  const patients = await fetch(API+'/patients').then(r=>r.json());
  patients.forEach(p=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${p.id}</td><td>${p.name}</td><td>${p.age}</td><td>${p.gender}</td><td>${p.notes||''}</td>
    <td><button class="btn-danger" onclick="deletePatient(${p.id})">Delete</button></td>`;
    body.appendChild(tr);
  });
  form.addEventListener('submit', async e=>{
    e.preventDefault();
    const fd = new FormData(form);
    const obj = {name:fd.get('name'), age: Number(fd.get('age')), gender: fd.get('gender'), notes: fd.get('notes')};
    await fetch(API+'/patients',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});
    loadPatientsUI();
    loadCounts();
  });
}

async function loadDoctorsUI(){
  const tpl = document.getElementById('doctors-template').content.cloneNode(true);
  content.innerHTML=''; content.appendChild(tpl);
  const body = document.getElementById('doctorsBody');
  const form = document.getElementById('doctorForm');
  const doctors = await fetch(API+'/doctors').then(r=>r.json());
  doctors.forEach(d=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${d.id}</td><td>${d.name}</td><td>${d.speciality}</td><td>${d.phone||''}</td>
    <td><button class="btn-danger" onclick="deleteDoctor(${d.id})">Delete</button></td>`;
    body.appendChild(tr);
  });
  form.addEventListener('submit', async e=>{
    e.preventDefault();
    const fd = new FormData(form);
    const obj = {name:fd.get('name'), speciality: fd.get('speciality'), phone: fd.get('phone')};
    await fetch(API+'/doctors',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});
    loadDoctorsUI();
    loadCounts();
  });
}

async function loadAppointmentsUI(){
  const tpl = document.getElementById('appointments-template').content.cloneNode(true);
  content.innerHTML=''; content.appendChild(tpl);
  const patients = await fetch(API+'/patients').then(r=>r.json());
  const doctors = await fetch(API+'/doctors').then(r=>r.json());
  const appts = await fetch(API+'/appointments').then(r=>r.json());
  const pSel = document.getElementById('apptPatient');
  const dSel = document.getElementById('apptDoctor');
  pSel.innerHTML = '<option value="">Select patient</option>';
  dSel.innerHTML = '<option value="">Select doctor</option>';
  patients.forEach(p=> pSel.innerHTML += `<option value="${p.id}">${p.name}</option>`);
  doctors.forEach(d=> dSel.innerHTML += `<option value="${d.id}">${d.name} (${d.speciality})</option>`);
  const body = document.getElementById('appointmentsBody');
  appts.forEach(a=>{
    const pat = patients.find(p=>p.id===a.patientId);
    const doc = doctors.find(d=>d.id===a.doctorId);
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${a.id}</td><td>${pat?pat.name:'-'}</td><td>${doc?doc.name:'-'}</td><td>${a.appointmentDate? new Date(a.appointmentDate).toLocaleString() : ''}</td><td>${a.reason||''}</td>
    <td><button class="btn-danger" onclick="deleteAppointment(${a.id})">Delete</button></td>`;
    body.appendChild(tr);
  });

  const form = document.getElementById('appointmentForm');
  form.addEventListener('submit', async e=>{
    e.preventDefault();
    const fd = new FormData(form);
    const obj = {patientId: Number(fd.get('patientId')), doctorId: Number(fd.get('doctorId')), appointmentDate: fd.get('appointmentDate'), reason: fd.get('reason')};
    await fetch(API+'/appointments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});
    loadAppointmentsUI();
    loadCounts();
  });
}

window.deletePatient = async (id)=> { await fetch(API+`/patients/${id}`,{method:'DELETE'}); loadPatientsUI(); loadCounts(); }
window.deleteDoctor = async (id)=> { await fetch(API+`/doctors/${id}`,{method:'DELETE'}); loadDoctorsUI(); loadCounts(); }
window.deleteAppointment = async (id)=> { await fetch(API+`/appointments/${id}`,{method:'DELETE'}); loadAppointmentsUI(); loadCounts(); }

// Start at dashboard
loadTab('dashboard');
