package com.example.hms.controller;

import com.example.hms.model.Patient;
import com.example.hms.repository.PatientRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = "*")
public class PatientController {
    private final PatientRepository repo;
    public PatientController(PatientRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Patient> list() { return repo.findAll(); }

    @GetMapping("/{id}")
    public Patient get(@PathVariable Long id) { return repo.findById(id).orElse(null); }

    @PostMapping
    public Patient create(@RequestBody Patient p) { return repo.save(p); }

    @PutMapping("/{id}")
    public Patient update(@PathVariable Long id, @RequestBody Patient p) { p.setId(id); return repo.save(p); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }
}
