package com.example.hms.controller;

import com.example.hms.model.Appointment;
import com.example.hms.repository.AppointmentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "*")
public class AppointmentController {
    private final AppointmentRepository repo;
    public AppointmentController(AppointmentRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Appointment> list() { return repo.findAll(); }

    @PostMapping
    public Appointment create(@RequestBody Appointment a) { return repo.save(a); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }
}
