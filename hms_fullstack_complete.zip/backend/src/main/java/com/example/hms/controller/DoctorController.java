package com.example.hms.controller;

import com.example.hms.model.Doctor;
import com.example.hms.repository.DoctorRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
@CrossOrigin(origins = "*")
public class DoctorController {
    private final DoctorRepository repo;
    public DoctorController(DoctorRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Doctor> list() { return repo.findAll(); }

    @PostMapping
    public Doctor create(@RequestBody Doctor d) { return repo.save(d); }

    @PutMapping("/{id}")
    public Doctor update(@PathVariable Long id, @RequestBody Doctor d) { d.setId(id); return repo.save(d); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }
}
