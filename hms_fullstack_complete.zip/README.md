# Hospital Management System - Complete (Backend + Vanilla Frontend)
This project includes a Spring Boot backend with H2 database and a modern Vanilla JS frontend.

## Requirements
- Java 17+
- Maven
- Browser to open frontend/index.html (or use from VS Code Live Server)

## Run Backend
1. Open terminal in `backend/`
2. Run: `mvn spring-boot:run`
3. H2 console (optional): http://localhost:8080/h2-console
   - JDBC URL: jdbc:h2:mem:hmsdb
   - user: sa (no password)

## Open Frontend
- Open `frontend-vanilla/index.html` in your browser.
- The frontend calls API endpoints at http://localhost:8080/api/*

## Features
- CRUD for Patients and Doctors (via H2/JPA)
- Create/Delete Appointments
- Modern dashboard UI (Vanilla JS)
